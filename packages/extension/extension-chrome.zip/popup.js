"use strict";
(() => {
  // src/defaults.ts
  var DEFAULT_RELAYS = [
    "wss://relay.damus.io",
    "wss://nos.lol",
    "wss://bitcoiner.social"
  ];
  var DEFAULT_VIEWER_BASE = "https://njump.me/";
  function getDebugFlag() {
    return new Promise((resolve) => {
      chrome.storage.sync.get(["nostrDebug"], ({ nostrDebug }) => {
        resolve(Boolean(nostrDebug));
      });
    });
  }
  function setDebugFlag(value) {
    return new Promise((resolve) => {
      chrome.storage.sync.set({ nostrDebug: value }, () => resolve());
    });
  }
  function getViewerBase() {
    return new Promise((resolve) => {
      chrome.storage.sync.get(["nostrViewerBase"], ({ nostrViewerBase }) => {
        const base = typeof nostrViewerBase === "string" && nostrViewerBase.trim() ? nostrViewerBase.trim() : DEFAULT_VIEWER_BASE;
        resolve(base);
      });
    });
  }
  function setViewerBase(value) {
    return new Promise((resolve) => {
      chrome.storage.sync.set({ nostrViewerBase: value }, () => resolve());
    });
  }

  // src/popup-logic.ts
  function normalizeRelays(lines) {
    const out = [];
    const invalid = [];
    const seen = /* @__PURE__ */ new Set();
    for (const raw of lines) {
      const s = raw.trim();
      if (!s) continue;
      if (!/^wss?:\/\//i.test(s)) {
        invalid.push(s);
        continue;
      }
      const url = s.replace(/\/$/, "");
      const low = url.toLowerCase();
      if (!seen.has(low)) {
        seen.add(low);
        out.push(url);
      }
    }
    return { relays: out, invalid };
  }
  function normalizeViewerBase(input) {
    const raw = (input || "").trim();
    let url = raw || "";
    if (!/^(https?:)\/\//i.test(url)) {
      url = url ? `https://${url}` : "";
    }
    if (!url) throw new Error("empty");
    const u = new URL(url);
    if (!u.pathname.endsWith("/")) {
      u.pathname = `${u.pathname}/`;
    }
    return u.toString();
  }

  // src/popup.ts
  var relayForm = document.getElementById("relayForm");
  var relayList = document.getElementById("relayList");
  var statusElement = document.getElementById("status");
  var resetBtn = document.getElementById("resetBtn");
  var debugToggle = document.getElementById("debugToggle");
  var viewerBaseInput = document.getElementById("viewerBase");
  var saveViewerBaseBtn = document.getElementById("saveViewerBaseBtn");
  var resetViewerBaseBtn = document.getElementById("resetViewerBaseBtn");
  function setStatus(msg) {
    if (statusElement) {
      statusElement.textContent = msg;
    }
  }
  chrome.storage.sync.get(["nostrRelays"], ({ nostrRelays }) => {
    if (!relayList) return;
    const relays = Array.isArray(nostrRelays) ? nostrRelays : DEFAULT_RELAYS;
    relayList.value = relays.join("\n");
  });
  var SHOW_DEBUG = true ? false : true;
  try {
    if (!SHOW_DEBUG) document.documentElement.setAttribute("hide-debug", "true");
  } catch {
  }
  if (SHOW_DEBUG) {
    getDebugFlag().then((on) => {
      if (debugToggle) debugToggle.checked = !!on;
    });
  } else {
    const row = debugToggle?.closest(".row") || debugToggle?.parentElement;
    if (row) row.style.display = "none";
    const help = document.getElementById("debugHelp");
    if (help) help.style.display = "none";
  }
  getViewerBase().then((base) => {
    if (viewerBaseInput) viewerBaseInput.value = base || DEFAULT_VIEWER_BASE;
  });
  relayForm?.addEventListener("submit", (e) => {
    e.preventDefault();
    if (!relayList) return;
    const lines = relayList.value.split("\n");
    const { relays, invalid } = normalizeRelays(lines);
    if (invalid.length) {
      relayList.setAttribute("aria-invalid", "true");
      setStatus(`Ignored invalid entries: ${invalid.join(", ")}`);
    } else {
      relayList.removeAttribute("aria-invalid");
      setStatus("");
    }
    chrome.storage.sync.set({ nostrRelays: relays }, () => {
      setStatus("Relays saved!");
      setTimeout(() => setStatus(""), 2e3);
    });
  });
  resetBtn?.addEventListener("click", () => {
    if (!relayList) return;
    relayList.value = DEFAULT_RELAYS.join("\n");
    chrome.storage.sync.set({ nostrRelays: DEFAULT_RELAYS }, () => {
      setStatus("Restored default relays.");
      setTimeout(() => setStatus(""), 2e3);
    });
  });
  if (SHOW_DEBUG) {
    debugToggle?.addEventListener("change", async (e) => {
      const on = e.target.checked;
      await setDebugFlag(on);
      setStatus(on ? "Debug: console-only enabled" : "Debug disabled");
      setTimeout(() => setStatus(""), 1500);
    });
  }
  saveViewerBaseBtn?.addEventListener("click", async () => {
    if (!viewerBaseInput) return;
    const raw = viewerBaseInput.value.trim();
    try {
      const url = normalizeViewerBase(raw || DEFAULT_VIEWER_BASE);
      await setViewerBase(url);
      viewerBaseInput.value = url;
      viewerBaseInput.removeAttribute("aria-invalid");
      setStatus("Viewer base URL saved.");
    } catch {
      viewerBaseInput.setAttribute("aria-invalid", "true");
      setStatus("Invalid URL. Example: https://njump.me/");
    }
    setTimeout(() => setStatus(""), 2e3);
  });
  resetViewerBaseBtn?.addEventListener("click", async () => {
    if (!viewerBaseInput) return;
    const url = DEFAULT_VIEWER_BASE;
    await setViewerBase(url);
    viewerBaseInput.value = url;
    viewerBaseInput.removeAttribute("aria-invalid");
    setStatus("Viewer base reset to default.");
    setTimeout(() => setStatus(""), 2e3);
  });
  window.__POPUP_READY__ = true;
})();
//# sourceMappingURL=popup.js.map
